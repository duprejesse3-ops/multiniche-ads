# MultiNicheADS /api/mcp → proxy to canonical storefront server

One file, replaces the existing one at this exact path in the
`duprejesse3-ops/multiniche-ads` repo:

```
src/routes/api/mcp.ts
```

## What changed and why

You now have one canonical MCP server — the storefront's
(`netlify/functions/mcp.mts` on the Jblessd repo, already committed as
`d6c6d67`, reachable at `https://multinicheai.com/api/mcp`). This file stops
duplicating that logic here and just forwards every request to it.

Why proxy instead of delete: anything that already found and connected to
`multiniche-ads.vercel.app/api/mcp` keeps working — it just transparently
gets the canonical server's (more complete, SDK-based) answers instead.

## Tested

`proxyToCanonical`'s core logic (forwards body + method, returns upstream
status/body/content-type verbatim) — 2/2 tests pass against mocked
responses, including a non-200 upstream status to confirm errors aren't
silently masked. The route file's structure was also syntax-verified.

**What I couldn't verify from here**: this repo's exact `createFileRoute`
generic typing (would need `npx tsc --noEmit` in the real repo, same as your
past sessions did for `preview-run.ts`) and a full `vite build`. Worth
running both before merging, matching your usual process.

## Before deploying either piece

1. **Confirm the storefront's own MCP server is actually live** — it was
   marked "shipped and pushed, live once Netlify redeploys" in an earlier
   session, which implies it may have been pending a deploy trigger:
   ```bash
   curl -X POST https://multinicheai.com/api/mcp \
     -H "Content-Type: application/json" \
     -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
   ```
   Should return 4 tools. If it 404s, that redeploy needs to happen first —
   this proxy would otherwise forward to a dead endpoint.

2. **Do not deploy the `storefront-mcp.zip` I gave you earlier this
   session** — it duplicates `/api/mcp` on the storefront with a different,
   less capable implementation at a conflicting path
   (`netlify/edge-functions/mcp.mts` vs the real
   `netlify/functions/mcp.mts`). Delete that zip or just don't use it.

## Verify after deploying this proxy

```bash
curl -X POST https://multiniche-ads.vercel.app/api/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

Should return the same 4 tools as the storefront's own endpoint — if it
does, the proxy is working correctly.
