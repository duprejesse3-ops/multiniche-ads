# Storefront MCP server for multinicheai.com

Two files, drop straight into the Jblessd repo at these exact paths:

```
netlify/edge-functions/mcp.mts
netlify/edge-functions/lib/mcp-core.mts
```

(`lib/test-mcp-core.mjs` is a test file, not part of the deployed function —
keep it in the repo for regression testing, but it never runs in production.)

## What it does

Exposes the live storefront catalog as four MCP tools, reachable at
`POST https://multinicheai.com/api/mcp`:

- **search_catalog** — keyword/niche/category search
- **get_product** — full detail by SKU
- **run_live_demo** — runs the same Live Proof demo the storefront itself
  uses (`/api/demo`) — this is the differentiator worth agents seeing
- **get_purchase_link** — returns the order-page URL only. It does **not**
  call `/api/create-checkout-session` or complete a purchase — no tool here
  can spend anyone's money. An agent gets a link to hand back to its user,
  same as it would get from browsing the site normally.

All four read from the *same* live Postgres-backed catalog the storefront
already serves (`/api/products`, `/api/demo`) — there's no separate data
source to keep in sync.

## Deploy

Same as your existing pattern: commit these two files, push, Netlify
auto-deploys. No new environment variables, no new dependencies — it's
plain TypeScript using only web-standard `Request`/`Response`, matching how
your other edge functions already work.

## Verify it's live

```bash
curl -X POST https://multinicheai.com/api/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

Should return the four tools. Then try a real call:

```bash
curl -X POST https://multinicheai.com/api/mcp \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/call","params":{"name":"search_catalog","arguments":{"niche":"founders"}}}'
```

## Before you deploy, worth deciding

You already have an MCP server on **MultiNicheADS** (`/api/mcp` there) that
proxies this same storefront catalog. Having two servers that both answer
for the same catalog isn't broken, but it's worth being intentional about:
point AI agents at whichever one you consider canonical, or keep both if
MultiNicheADS's version adds something this one doesn't (it was built with
the ad-exchange/agent-protocol angle in mind).

## This alone doesn't make you "show up in AI search"

Worth repeating from before: this makes the catalog *discoverable by an
agent that already knows to look for it* — it doesn't put you in front of
new agents or users on its own. The next real step, if you want that, is
submitting this server's URL to MCP directories/registries so agents (like
Claude, when someone asks it to find a tool) can actually find it in the
first place. That's a separate piece of work — happy to help with it once
this is live and verified in production.
