// MultiNicheAI storefront MCP server.
//
// Exposes the live product catalog (the same data backing the storefront's
// own /api/products and /api/demo) as MCP tools an AI agent can call:
// search_catalog, get_product, run_live_demo, get_purchase_link.
//
// Deliberately does NOT expose checkout/purchase-completion as a tool —
// get_purchase_link only returns the order-page URL for a human to open and
// confirm themselves. No tool here can spend the user's money.
import { handleMcpRequest } from './lib/mcp-core.mts';

export default async (request: Request) => {
  if (request.method !== 'POST') {
    return new Response('Method not allowed — POST JSON-RPC 2.0 requests only.', { status: 405 });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return new Response(
      JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } }),
      { status: 400, headers: { 'Content-Type': 'application/json' } }
    );
  }

  const origin = new URL(request.url).origin;
  const response = await handleMcpRequest(body, { origin, fetchImpl: fetch });

  if (response === null) return new Response(null, { status: 204 });

  return new Response(JSON.stringify(response), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
};

export const config = { path: '/api/mcp' };
