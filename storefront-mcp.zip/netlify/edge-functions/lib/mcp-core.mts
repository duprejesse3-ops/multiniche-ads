// Pure logic for the storefront MCP server — no Deno/Netlify APIs used here,
// so this file is testable with plain Node (see test-mcp-core.mjs) before it
// ever touches the edge runtime.

export const TOOLS = [
  {
    name: 'search_catalog',
    description: 'Search the MultiNicheAI product catalog by keyword, niche, and/or category. Returns matching products with sku, name, price, and a short blurb.',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Free-text search across product name and blurb' },
        niche: { type: 'string', description: 'Filter by niche key: founders, sales, marketers, developers, writers, students, office, finance, architects, engineers, stores' },
        category: { type: 'string', description: 'Filter by category key: prompts, automations, templates, agents' },
        limit: { type: 'number', description: 'Max results to return (default 10)' }
      }
    }
  },
  {
    name: 'get_product',
    description: 'Get full details for one product by SKU: price, format, spec, and full description.',
    inputSchema: {
      type: 'object',
      properties: { sku: { type: 'string', description: 'Product SKU, e.g. AI-AG-003' } },
      required: ['sku']
    }
  },
  {
    name: 'run_live_demo',
    description: "Run a live proof demo of a product to show it actually working, before purchase. This is MultiNicheAI's core differentiator versus static product listings.",
    inputSchema: {
      type: 'object',
      properties: {
        sku: { type: 'string' },
        inputs: { type: 'object', description: 'Optional demo inputs specific to the product' }
      },
      required: ['sku']
    }
  },
  {
    name: 'get_purchase_link',
    description: 'Get the checkout/order page URL for a product. Does NOT complete a purchase — returns a link for a human to open and confirm themselves. Use this instead of trying to complete checkout directly.',
    inputSchema: {
      type: 'object',
      properties: { sku: { type: 'string' } },
      required: ['sku']
    }
  }
];

async function fetchCatalog(origin, fetchImpl) {
  const res = await fetchImpl(`${origin}/api/products`);
  if (!res.ok) throw new Error(`Catalog fetch failed: ${res.status}`);
  const data = await res.json();
  return Array.isArray(data) ? data : data.products || [];
}

async function searchCatalog({ query, niche, category, limit = 10 }, origin, fetchImpl) {
  const products = await fetchCatalog(origin, fetchImpl);
  const q = (query || '').toLowerCase();

  return products
    .filter((p) => {
      if (niche && p.niche !== niche) return false;
      if (category && p.category !== category) return false;
      if (q && !`${p.name} ${p.blurb}`.toLowerCase().includes(q)) return false;
      return true;
    })
    .slice(0, limit)
    .map((p) => ({ sku: p.sku || p.id, name: p.name, category: p.category, niche: p.niche, price: p.price, blurb: p.blurb }));
}

async function getProduct({ sku }, origin, fetchImpl) {
  if (!sku) throw new Error('sku is required');
  const products = await fetchCatalog(origin, fetchImpl);
  const product = products.find((p) => (p.sku || p.id) === sku);
  if (!product) throw new Error(`No product found for sku ${sku}`);
  return product;
}

async function runLiveDemo({ sku, inputs }, origin, fetchImpl) {
  if (!sku) throw new Error('sku is required');
  const res = await fetchImpl(`${origin}/api/demo`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sku, inputs: inputs || {} })
  });
  if (!res.ok) throw new Error(`Demo run failed: ${res.status}`);
  return res.json();
}

function getPurchaseLink({ sku }, origin) {
  if (!sku) throw new Error('sku is required');
  return { sku, url: `${origin}/order?sku=${encodeURIComponent(sku)}` };
}

export async function callTool(name, args, { origin, fetchImpl }) {
  switch (name) {
    case 'search_catalog': return searchCatalog(args, origin, fetchImpl);
    case 'get_product': return getProduct(args, origin, fetchImpl);
    case 'run_live_demo': return runLiveDemo(args, origin, fetchImpl);
    case 'get_purchase_link': return getPurchaseLink(args, origin);
    default: throw new Error(`Unknown tool: ${name}`);
  }
}

// JSON-RPC 2.0 handler per the MCP spec's stateless HTTP transport — one
// request in, one response out, no session/SSE machinery needed for a
// tools-only server like this one.
export async function handleMcpRequest(body, ctx) {
  const { id, method, params } = body || {};

  if (method === 'notifications/initialized') return null; // no response for notifications

  try {
    let result;
    if (method === 'initialize') {
      result = {
        protocolVersion: '2024-11-05',
        serverInfo: { name: 'multinicheai-storefront', version: '1.0.0' },
        capabilities: { tools: {} }
      };
    } else if (method === 'tools/list') {
      result = { tools: TOOLS };
    } else if (method === 'tools/call') {
      const { name, arguments: args } = params || {};
      const toolResult = await callTool(name, args || {}, ctx);
      result = { content: [{ type: 'text', text: JSON.stringify(toolResult) }] };
    } else {
      throw new Error(`Method not found: ${method}`);
    }
    return { jsonrpc: '2.0', id, result };
  } catch (err) {
    return { jsonrpc: '2.0', id, error: { code: -32000, message: err.message } };
  }
}
