# MultiNicheADS /api/mcp → proxy to canonical storefront server

One file, replaces the existing one at this exact path in the
`duprejesse3-ops/multiniche-ads` repo:

```
src/routes/api/mcp.ts
```

## What changed and why

You now have one canonical MCP server — the storefront's
(`netlify/functions/mcp.mts` on the Jblessd repo, already committed as
`d6c6d67`, reachable at `https://multinicheai.com/api/mcp`). This file stops
duplicating that logic here and just forwards every request to it.

Why proxy instead of delete: anything that already found and connected to
`multiniche-ads.vercel.app/api/mcp` keeps working — it just transparently
gets the canonical server's (more complete, SDK-based) answers instead.

## Tested

`proxyToCanonical`'s core logic — forwards body/method, returns upstream
status/body/content-type verbatim, and (after a bug found via a live curl
test against the real server) correctly forwards the client's `Accept`
header. 4/4 tests pass, including a regression test for that exact bug.

**The bug, for the record**: the canonical server's transport (the real MCP
SDK) strictly requires `Accept: application/json, text/event-stream` per
the MCP spec, and 406s anything else — confirmed live. The first version of
this proxy didn't forward that header, so it would have hit the same
rejection. Real MCP clients always send it correctly, so the fix was simply
to pass it through instead of letting `fetch()` supply its own default.

**What I couldn't verify from here**: this repo's exact `createFileRoute`
generic typing (would need `npx tsc --noEmit` in the real repo, same as your
past sessions did for `preview-run.ts`) and a full `vite build`. Worth
running both before merging, matching your usual process.

## Before deploying either piece

1. **Confirm the storefront's own MCP server is actually live** — it was
   marked "shipped and pushed, live once Netlify redeploys" in an earlier
   session. Now confirmed live and correctly protocol-strict:
   ```bash
   curl -X POST https://multinicheai.com/api/mcp \
     -H "Content-Type: application/json" \
     -H "Accept: application/json, text/event-stream" \
     -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
   ```
   Should return 4 tools. (Omitting the `Accept` header gets a `406 Not
   Acceptable` — that's the real SDK correctly enforcing the MCP spec, not
   a sign anything's broken.)

2. **Do not deploy the `storefront-mcp.zip` I gave you earlier this
   session** — it duplicates `/api/mcp` on the storefront with a different,
   less capable implementation at a conflicting path
   (`netlify/edge-functions/mcp.mts` vs the real
   `netlify/functions/mcp.mts`). Delete that zip or just don't use it.

## Verify after deploying this proxy

```bash
curl -X POST https://multiniche-ads.vercel.app/api/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

Should return the same 4 tools as the storefront's own endpoint — if it
does, the proxy is working correctly.
