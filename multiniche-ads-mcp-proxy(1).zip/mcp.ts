// Replaces this file's contents. MultiNicheADS's own MCP tools were merged
// into the storefront's server (netlify/functions/mcp.mts on the Jblessd
// repo, commit d6c6d67) as the single canonical source — this file now just
// forwards requests there instead of duplicating the implementation.
//
// This keeps any agent already pointed at multiniche-ads.vercel.app/api/mcp
// working without a broken link, while there being exactly one place the
// actual catalog/demo/tool logic lives.
import { createFileRoute } from "@tanstack/react-router";

const CANONICAL_MCP_URL = "https://multinicheai.com/api/mcp";

async function proxyToCanonical(request: Request) {
  const body = await request.text();
  // The canonical server's transport (real MCP SDK, StreamableHTTPServerTransport)
  // strictly requires an Accept header with both application/json and
  // text/event-stream — confirmed live against the deployed server, which 406s
  // without it. Real MCP clients send this correctly; forward it through
  // rather than letting fetch() pick its own default.
  const accept = request.headers.get("Accept") ?? "application/json, text/event-stream";

  const upstream = await fetch(CANONICAL_MCP_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: accept },
    body,
  });
  const text = await upstream.text();
  return new Response(text, {
    status: upstream.status,
    headers: { "Content-Type": upstream.headers.get("Content-Type") ?? "application/json" },
  });
}

export const Route = createFileRoute("/api/mcp")({
  server: {
    handlers: {
      POST: async ({ request }) => proxyToCanonical(request),
    },
  },
});
